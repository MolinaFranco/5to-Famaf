some sig Foo {}

